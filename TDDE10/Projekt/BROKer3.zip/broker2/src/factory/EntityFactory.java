package factory;

import entites.Entity;
import entites.Parent;
import entites.Student;
import entites.Teacher;

public class EntityFactory {
	
	public EntityFactory()
	{
		
	}
	
	public Entity getEntity(String entityType){
	      if(entityType == null){
	         return null;
	      }		
	      if(entityType.equalsIgnoreCase("STUDENT")){
	         return new Student();
	         
	      } else if(entityType.equalsIgnoreCase("TEACHER")){
	         return new Teacher();
	         
	      } else if(entityType.equalsIgnoreCase("PARENT")){
	         return new Parent();
	      }
	      
	      return null;
	   }
}
