package entites;

public class Teacher extends Entity{
	
	
	public Teacher()
	{
		super();
	}
	
	public Teacher(String name, int personnummer, String email)
	{
		super(name, personnummer, email);
	}
}
