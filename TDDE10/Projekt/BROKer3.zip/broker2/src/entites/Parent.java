package entites;

public class Parent extends Entity{
	
	
	public Parent()
	{
		super();
	}
	
	public Parent(String name, int personnummer, String email)
	{
		super(name, personnummer, email);
	}

}
