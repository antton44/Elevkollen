package minterface;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import entites.Course;

public class Window extends JFrame{
	
	public Window(Course course)
	{
		super("Elevkontrollen");
		StudentList list = new StudentList(course);
		super.add(list, BorderLayout.CENTER);
	}
}
