package minterface;

import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JComboBox;
import javax.swing.JPanel;

import entites.Course;



public class StudentList extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gbc;
	private Course course;
	private JComboBox<String> absenceList;
	
	String[] absences = { "Ogiltig", "anmäld" };

	//Create the combo box, select item at index 4.
		//Indices start at 0, so 4 specifies the pig.
		

	//Konstruktor
	public StudentList(Course course) {
		super.setSize(20, 10);
		setLayout(new GridBagLayout());
		gbc = new GridBagConstraints();
		
		this.course = course;
		absenceList = new JComboBox<String>(absences);
		absenceList.setSelectedIndex(1);
		add(absenceList, gbc);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for(int i = 0; i < course.getSize(); i++)
		{
			g.drawString(course.getStudent(i).toString(), 200, 100 + i*50);
			add(new JComboBox<String>(absences), gbc);
			//absenceList.addActionListener(this);
		}
		
	}
}
