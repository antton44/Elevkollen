package main;

import javax.swing.JFrame;

import minterface.Window;
import entites.Course;
import entites.Student;

public class Start {

	public static void main(String[] args) {
		Course historia = new Course("123", "Historia A");
		
		historia.addStudent(new Student("Rasmus", 1996032033, "ras@gmail.com", 8));
		historia.addStudent(new Student("Kalle", 1998032033, "kalle@gmail.com", 6));
		historia.addStudent(new Student("Jonna", 1992032033, "jonna@gmail.com", 8));
		historia.addStudent(new Student("Kim", 1994032033, "kim@gmail.com", 4));
		
		Window window = new Window(historia);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(800, 600);
		window.setVisible(true);

	}

}
