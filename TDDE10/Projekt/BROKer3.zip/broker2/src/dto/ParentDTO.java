package dto;

public class ParentDTO extends DataTransferObject{
	private int personnummer;
	private String name;
	private String email;

	public ParentDTO(int personnummer, String name, String email)
	{
		this.personnummer = personnummer;
		this.name = name;
		this.email = email;
	}
}
