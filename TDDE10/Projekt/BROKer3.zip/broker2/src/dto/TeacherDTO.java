package dto;

public class TeacherDTO extends DataTransferObject{
	private int personnummer;
	private String name;
	private String email;
	
	public TeacherDTO(int personnummer, String name, String email)
	{
		this.personnummer = personnummer;
		this.name = name;
		this.email = email;
	}
}
