package dto;

public class ClassDTO extends DataTransferObject{
	private int classID;
	private String name;

	public ClassDTO(int classID, String name)
	{
		this.classID = classID;
		this.name = name;
	}
}
