package dto;

public class SemesterDTO extends DataTransferObject{
	private String id;

	public SemesterDTO(String id)
	{
		this.id = id;
	}
}
