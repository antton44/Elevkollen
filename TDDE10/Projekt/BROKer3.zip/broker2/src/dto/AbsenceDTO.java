package dto;

import entites.Course;
import entites.Student;

public class AbsenceDTO extends DataTransferObject{
	private Student absentStudent;
	private Course course;
	private Boolean unauthorizedAbsence;
	
	public AbsenceDTO(Student absentStudent, Course course, Boolean unauthorizedAbsence)
	{
		this.absentStudent = absentStudent;
		this.course = course;
		this.unauthorizedAbsence = unauthorizedAbsence;
	}
}
