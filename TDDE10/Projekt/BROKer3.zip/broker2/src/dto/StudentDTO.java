package dto;

import broker.StudentBroker;

public class StudentDTO extends DataTransferObject{
	private int personnummer;
	private String name;
	private String email;
	private int year;

	public StudentDTO(int personnummer, String name, String email, int year)
	{
		this.personnummer = personnummer;
		this.name = name;
		this.email = email;
		this.year = year;
		this.broker = new StudentBroker(); //FIXA SENARE
	}
}
