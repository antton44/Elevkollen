package broker;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class CourseBroker  extends Broker {

	// DATABAS
	@Override
	public void insertStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("INSERT INTO Kurs(KursID, Namn) VALUES (123457, 'Svenska 1')");
			conn.close();
		}catch (Throwable e) {

		} 
		
	}

	@Override
	public void updateStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("UPDATE Kurs(KursID, Namn) VALUES (123456, 'Svenska 2')");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void deleteStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("DELETE FROM Kurs WHERE KursID = 123456");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void getFromStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * FROM Kurs");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public Object findInStorage(UUID id) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * Lärare WHERE Personummer = 960714");
			conn.close();
		}catch (Throwable e) {

		} 
		return null;
	}

}