package broker;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class SemesterBroker  extends Broker {

	// DATABAS
	@Override
	public void insertStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("INSERT INTO Termin(TerminID) VALUES ('VT17')");
			conn.close();
		}catch (Throwable e) {

		} 
		
	}

	@Override
	public void updateStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("UPDATE Termin(TerminID) VALUES ('HT18')");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void deleteStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("DELETE FROM Termin WHERE TerminID = HT18");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void getFromStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * FROM Termin");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public Object findInStorage(UUID id) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * Termin WHERE TerminID = HT18");
			conn.close();
		}catch (Throwable e) {

		} 
		return null;
	}

}