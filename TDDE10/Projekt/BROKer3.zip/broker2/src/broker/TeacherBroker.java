package broker;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class TeacherBroker extends Broker {

	// DATABAS
	@Override
	public void insertStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("INSERT INTO Förälder(Personummer, Namn, Email) VALUES (6900917, 'Tor', 'tor@gmail.com')");
			conn.close();
		}catch (Throwable e) {

		} 
		
	}

	@Override
	public void updateStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("UPDATE Förälder(Personummer, Namn, Email) VALUES (6900918, 'Torsten', 'torsten@gmail.com')");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void deleteStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("DELETE FROM Förälder WHERE Personummer = 6900918");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void getFromStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * FROM Förälder");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public Object findInStorage(UUID id) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * Förälder WHERE Personummer = 6900918");
			conn.close();
		}catch (Throwable e) {

		} 
		return null;
	}

}
