package broker;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class StudentBroker extends Broker {

	// DATABAS
	@Override
	public void insertStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("INSERT INTO Elev(Personummer, Namn, Årskurs, Email) VALUES (123, 'Pelle', 2, 'pelle@gmail.com') ");
			conn.close();
		}catch (Throwable e) {

		} 
		
	}

	@Override
	public void updateStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("UPDATE Elev(Personummer, Namn, Årskurs, Email) VALUES (960714, 'Sven', 1, 'svenbajs@gmail.com')");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void deleteStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("DELETE FROM Elev WHERE Personummer = 960714");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void getFromStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * FROM Elev");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public Object findInStorage(UUID id) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * Elev WHERE Personummer = 960714");
			conn.close();
		}catch (Throwable e) {

		} 
		return null;
	}

}
