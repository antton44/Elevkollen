package broker;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class ParentBroker  extends Broker {

	// DATABAS
	@Override
	public void insertStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("INSERT INTO Lärare(Personummer, Namn, Email) VALUES (6300917, 'Greger', 'greger@gmail.com')");
			conn.close();
		}catch (Throwable e) {

		} 
		
	}

	@Override
	public void updateStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("UPDATE Lärare(Personummer, Namn, Email) VALUES (6300918, 'Jesper', 'gregerNOT@gmail.com')");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void deleteStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("DELETE FROM Lärare WHERE Personummer = 6300918");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public void getFromStorage(Object object) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * FROM Lärare");
			conn.close();
		}catch (Throwable e) {

		} 
	}

	@Override
	public Object findInStorage(UUID id) throws SQLException {
		DBConnection dbcon = new DBConnection();
		Connection conn = dbcon.getConnection();
		
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate("SELECT * Lärare WHERE Personummer = 960714");
			conn.close();
		}catch (Throwable e) {

		} 
		return null;
	}

}